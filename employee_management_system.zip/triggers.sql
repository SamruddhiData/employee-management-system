-- Trigger to validate leave days
CREATE OR REPLACE TRIGGER trg_validate_leave
BEFORE INSERT ON leaves
FOR EACH ROW
BEGIN
    IF :NEW.leave_days > 5 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Leave days cannot exceed 5 at a time.');
    END IF;
END;
/