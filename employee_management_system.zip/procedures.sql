-- Procedure to process monthly salary
CREATE OR REPLACE PROCEDURE process_monthly_salary(p_month IN VARCHAR2) AS
BEGIN
    FOR rec IN (SELECT emp_id, salary FROM employees) LOOP
        INSERT INTO payroll (payroll_id, emp_id, month, net_salary)
        VALUES (payroll_seq.NEXTVAL, rec.emp_id, p_month, rec.salary);
    END LOOP;
    COMMIT;
END;
/