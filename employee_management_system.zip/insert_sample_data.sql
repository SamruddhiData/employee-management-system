-- Insert sample departments
INSERT INTO departments VALUES (1, 'HR');
INSERT INTO departments VALUES (2, 'IT');
INSERT INTO departments VALUES (3, 'Finance');

-- Insert sample employees
INSERT INTO employees VALUES (101, 'Alice', 2, TO_DATE('2022-01-15', 'YYYY-MM-DD'), 50000);
INSERT INTO employees VALUES (102, 'Bob', 1, TO_DATE('2021-11-10', 'YYYY-MM-DD'), 45000);
INSERT INTO employees VALUES (103, 'Charlie', 3, TO_DATE('2020-06-05', 'YYYY-MM-DD'), 60000);

-- Insert sample leaves
INSERT INTO leaves VALUES (1, 101, TO_DATE('2024-07-01', 'YYYY-MM-DD'), 2, 'Approved');
INSERT INTO leaves VALUES (2, 102, TO_DATE('2024-07-03', 'YYYY-MM-DD'), 1, 'Pending');

-- Insert sample payroll
INSERT INTO payroll VALUES (1, 101, 'July', 50000);
INSERT INTO payroll VALUES (2, 102, 'July', 45000);