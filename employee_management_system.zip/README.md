# 🧾 Employee Management System (HRMS) – SQL & PL/SQL Project

## 🔍 Overview
A full-featured Employee Management System using Oracle SQL & PL/SQL. It manages employees, departments, leaves, and salary processing.

## 📂 Contents
- `create_tables.sql`: Creates the main HRMS tables
- `insert_sample_data.sql`: Inserts demo data for testing
- `procedures.sql`: Contains the salary calculation procedure
- `triggers.sql`: Contains validation trigger for leave

## 🛠️ Technologies Used
- Oracle SQL
- PL/SQL
- SQL Developer

## 👩‍💻 Author
**Samruddhi Sandip Gunjal**  
🎓 B.E. Computer Engineering, GSMCOE Pune (2026)  
🔗 GitHub: [SamruddhiData](https://github.com/SamruddhiData)