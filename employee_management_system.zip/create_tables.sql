-- Create Employees Table
CREATE TABLE employees (
    emp_id NUMBER PRIMARY KEY,
    emp_name VARCHAR2(100),
    dept_id NUMBER,
    hire_date DATE,
    salary NUMBER(10, 2)
);

-- Create Departments Table
CREATE TABLE departments (
    dept_id NUMBER PRIMARY KEY,
    dept_name VARCHAR2(100)
);

-- Create Leaves Table
CREATE TABLE leaves (
    leave_id NUMBER PRIMARY KEY,
    emp_id NUMBER,
    leave_date DATE,
    leave_days NUMBER,
    status VARCHAR2(20)
);

-- Create Payroll Table
CREATE TABLE payroll (
    payroll_id NUMBER PRIMARY KEY,
    emp_id NUMBER,
    month VARCHAR2(10),
    net_salary NUMBER(10, 2)
);